Shadows of War browser client third-party licenses
Target: wasm32-unknown-unknown; linked normal dependency closure of sow-client.
External runtime packages: 120. Build-only, development, and proc-macro packages are excluded.
For each OR expression, the package is used under the listed permitted option. AND terms are all retained.
Each package folder contains the license text from the exact crate version; when the crate archive omits it, the standard SPDX text is provided.

adler2 2.0.1
  License applied: MIT
  Authors: Jonas Schievink <jonasschievink@gmail.com>; oyvindln <oyvindln@users.noreply.github.com>
  Source: https://github.com/oyvindln/adler2
  MIT: licenses/adler2-2.0.1/LICENSE-MIT (crate license file)
alloc-no-stdlib 2.0.4
  License applied: BSD-3-Clause
  Authors: Daniel Reiter Horn <danielrh@dropbox.com>
  Source: https://github.com/dropbox/rust-alloc-no-stdlib
  BSD-3-Clause: licenses/alloc-no-stdlib-2.0.4/LICENSE (crate license file)
alloc-stdlib 0.2.4
  License applied: BSD-3-Clause
  Authors: Daniel Reiter Horn <danielrh@dropbox.com>
  Source: https://github.com/dropbox/rust-alloc-no-stdlib
  BSD-3-Clause: licenses/alloc-stdlib-0.2.4/LICENSE-BSD-3-Clause.txt (standard SPDX text; crate archive has no license file)
arrayvec 0.7.8
  License applied: MIT
  Authors: bluss
  Source: https://github.com/bluss/arrayvec
  MIT: licenses/arrayvec-0.7.8/LICENSE-MIT (crate license file)
bincode 1.3.3
  License applied: MIT
  Authors: Ty Overby <ty@pre-alpha.com>; Francesco Mazzoli <f@mazzo.li>; David Tolnay <dtolnay@gmail.com>; Zoey Riordan <zoey@dos.cafe>
  Source: https://github.com/servo/bincode
  MIT: licenses/bincode-1.3.3/LICENSE.md (crate license file)
bit-set 0.10.0
  License applied: MIT
  Authors: Alexis Beingessner <a.beingessner@gmail.com>
  Source: https://github.com/contain-rs/bit-set
  MIT: licenses/bit-set-0.10.0/LICENSE-MIT (crate license file)
bit-vec 0.9.1
  License applied: MIT
  Authors: Alexis Beingessner <a.beingessner@gmail.com>
  Source: https://github.com/contain-rs/bit-vec
  MIT: licenses/bit-vec-0.9.1/LICENSE-MIT (crate license file)
bitfield 0.17.0
  License applied: MIT
  Authors: Loïc Damien <loic.damien@dzamlo.ch>
  Source: https://github.com/dzamlo/rust-bitfield
  MIT: licenses/bitfield-0.17.0/LICENSE-MIT (crate license file)
bitflags 2.13.2
  License applied: MIT
  Authors: The Rust Project Developers
  Source: https://github.com/bitflags/bitflags
  MIT: licenses/bitflags-2.13.2/LICENSE-MIT (crate license file)
blake3 1.8.7
  License applied: CC0-1.0
  Authors: Jack O'Connor <oconnor663@gmail.com>; Samuel Neves
  Source: https://github.com/BLAKE3-team/BLAKE3
  CC0-1.0: licenses/blake3-1.8.7/LICENSE_CC0 (crate license file)
borsh 1.8.1
  License applied: MIT
  Authors: Near Inc <hello@near.org>
  Source: https://github.com/near/borsh-rs
  MIT: licenses/borsh-1.8.1/LICENSE-MIT (crate license file)
brotli 8.0.4
  License applied: BSD-3-Clause AND MIT
  Authors: Daniel Reiter Horn <danielrh@dropbox.com>; The Brotli Authors
  Source: https://github.com/dropbox/rust-brotli
  BSD-3-Clause: licenses/brotli-8.0.4/LICENSE.BSD-3-Clause (crate license file)
  MIT: licenses/brotli-8.0.4/LICENSE.MIT (crate license file)
brotli-decompressor 5.0.3
  License applied: MIT
  Authors: Daniel Reiter Horn <danielrh@dropbox.com>; The Brotli Authors
  Source: https://github.com/dropbox/rust-brotli-decompressor
  MIT: licenses/brotli-decompressor-5.0.3/LICENSE (crate license file)
bytemuck 1.25.2
  License applied: MIT
  Authors: Lokathor <zefria@gmail.com>
  Source: https://github.com/Lokathor/bytemuck
  MIT: licenses/bytemuck-1.25.2/LICENSE-MIT (crate license file)
byteorder-lite 0.1.0
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/image-rs/byteorder-lite
  MIT: licenses/byteorder-lite-0.1.0/LICENSE-MIT (crate license file)
bytes 1.12.1
  License applied: MIT
  Authors: Carl Lerche <me@carllerche.com>; Sean McArthur <sean@seanmonstar.com>
  Source: https://github.com/tokio-rs/bytes
  MIT: licenses/bytes-1.12.1/LICENSE (crate license file)
cfg-if 1.0.5
  License applied: MIT
  Authors: Alex Crichton <alex@alexcrichton.com>
  Source: https://github.com/rust-lang/cfg-if
  MIT: licenses/cfg-if-1.0.5/LICENSE-MIT (crate license file)
codespan-reporting 0.13.1
  License applied: Apache-2.0
  Authors: Brendan Zabarauskas <bjzaba@yahoo.com.au>
  Source: https://github.com/brendanzab/codespan
  Apache-2.0: licenses/codespan-reporting-0.13.1/LICENSE (crate license file)
console_error_panic_hook 0.1.7
  License applied: MIT
  Authors: Nick Fitzgerald <fitzgen@gmail.com>
  Source: https://github.com/rustwasm/console_error_panic_hook
  MIT: licenses/console_error_panic_hook-0.1.7/LICENSE-MIT (crate license file)
console_log 1.1.0
  License applied: MIT
  Authors: Matthew Nicholson <matt@matt-land.com>
  Source: https://github.com/iamcodemaker/console_log
  MIT: licenses/console_log-1.1.0/LICENSE-MIT (crate license file)
constant_time_eq 0.4.2
  License applied: CC0-1.0
  Authors: Cesar Eduardo Barros <cesarb@cesarb.eti.br>
  Source: https://github.com/cesarb/constant_time_eq
  CC0-1.0: licenses/constant_time_eq-0.4.2/LICENSE-CC0 (crate license file)
cpal 0.17.3
  License applied: Apache-2.0
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/RustAudio/cpal
  Apache-2.0: licenses/cpal-0.17.3/LICENSE (crate license file)
crc32fast 1.5.2
  License applied: MIT
  Authors: Sam Rijs <srijs@airpost.net>; Alex Crichton <alex@alexcrichton.com>
  Source: https://github.com/srijs/rust-crc32fast
  MIT: licenses/crc32fast-1.5.2/LICENSE-MIT (crate license file)
crossbeam-channel 0.5.17
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/crossbeam-rs/crossbeam
  MIT: licenses/crossbeam-channel-0.5.17/LICENSE-MIT (crate license file)
crossbeam-utils 0.8.23
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/crossbeam-rs/crossbeam
  MIT: licenses/crossbeam-utils-0.8.23/LICENSE-MIT (crate license file)
cursor-icon 1.2.0
  License applied: MIT
  Authors: Kirill Chibisov <contact@kchibisov.com>
  Source: https://github.com/rust-windowing/cursor-icon
  MIT: licenses/cursor-icon-1.2.0/LICENSE-MIT (crate license file)
dasp_sample 0.11.0
  License applied: MIT
  Authors: mitchmindtree <mitchell.nordine@gmail.com>
  Source: https://github.com/rustaudio/sample.git
  MIT: licenses/dasp_sample-0.11.0/LICENSE-MIT.txt (standard SPDX text; crate archive has no license file)
dpi 0.1.2
  License applied: Apache-2.0 AND MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-windowing/winit
  Apache-2.0: licenses/dpi-0.1.2/LICENSE (crate license file)
  MIT: licenses/dpi-0.1.2/LICENSE-LIBM-MIT (crate license file)
ehttp 0.5.0
  License applied: MIT
  Authors: Emil Ernerfeldt <emil.ernerfeldt@gmail.com>
  Source: https://github.com/emilk/ehttp
  MIT: licenses/ehttp-0.5.0/LICENSE-MIT.txt (standard SPDX text; crate archive has no license file)
equivalent 1.0.2
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/indexmap-rs/equivalent
  MIT: licenses/equivalent-1.0.2/LICENSE-MIT (crate license file)
fdeflate 0.3.7
  License applied: MIT
  Authors: The image-rs Developers
  Source: https://github.com/image-rs/fdeflate
  MIT: licenses/fdeflate-0.3.7/LICENSE-MIT (crate license file)
flate2 1.1.10
  License applied: MIT
  Authors: Alex Crichton <alex@alexcrichton.com>; Josh Triplett <josh@joshtriplett.org>
  Source: https://github.com/rust-lang/flate2-rs
  MIT: licenses/flate2-1.1.10/LICENSE-MIT (crate license file)
foldhash 0.2.0
  License applied: Zlib
  Authors: Orson Peters <orsonpeters@gmail.com>
  Source: https://github.com/orlp/foldhash
  Zlib: licenses/foldhash-0.2.0/LICENSE (crate license file)
form_urlencoded 1.2.2
  License applied: MIT
  Authors: The rust-url developers
  Source: https://github.com/servo/rust-url
  MIT: licenses/form_urlencoded-1.2.2/LICENSE-MIT (crate license file)
futures-channel 0.3.34
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-lang/futures-rs
  MIT: licenses/futures-channel-0.3.34/LICENSE-MIT (crate license file)
futures-core 0.3.34
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-lang/futures-rs
  MIT: licenses/futures-core-0.3.34/LICENSE-MIT (crate license file)
futures-io 0.3.34
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-lang/futures-rs
  MIT: licenses/futures-io-0.3.34/LICENSE-MIT (crate license file)
futures-sink 0.3.34
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-lang/futures-rs
  MIT: licenses/futures-sink-0.3.34/LICENSE-MIT (crate license file)
futures-task 0.3.34
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-lang/futures-rs
  MIT: licenses/futures-task-0.3.34/LICENSE-MIT (crate license file)
futures-util 0.3.34
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-lang/futures-rs
  MIT: licenses/futures-util-0.3.34/LICENSE-MIT (crate license file)
getrandom 0.2.17
  License applied: MIT
  Authors: The Rand Project Developers
  Source: https://github.com/rust-random/getrandom
  MIT: licenses/getrandom-0.2.17/LICENSE-MIT (crate license file)
glow 0.16.0
  License applied: MIT
  Authors: Joshua Groves <josh@joshgroves.com>; Dzmitry Malyshau <kvarkus@gmail.com>
  Source: https://github.com/grovesNL/glow
  MIT: licenses/glow-0.16.0/LICENSE-MIT (crate license file)
half 2.7.1
  License applied: MIT
  Authors: Kathryn Long <squeeself@gmail.com>
  Source: https://github.com/VoidStarKat/half-rs
  MIT: licenses/half-2.7.1/LICENSE-MIT (crate license file)
hashbrown 0.17.1
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-lang/hashbrown
  MIT: licenses/hashbrown-0.17.1/LICENSE-MIT (crate license file)
icu_collections 2.3.0
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/icu_collections-2.3.0/LICENSE (crate license file)
icu_locale_core 2.3.0
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/icu_locale_core-2.3.0/LICENSE (crate license file)
icu_normalizer 2.3.0
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/icu_normalizer-2.3.0/LICENSE (crate license file)
icu_normalizer_data 2.3.0
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/icu_normalizer_data-2.3.0/LICENSE (crate license file)
icu_properties 2.3.0
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/icu_properties-2.3.0/LICENSE (crate license file)
icu_properties_data 2.3.0
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/icu_properties_data-2.3.0/LICENSE (crate license file)
icu_provider 2.3.1
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/icu_provider-2.3.1/LICENSE (crate license file)
idna 1.1.0
  License applied: MIT
  Authors: The rust-url developers
  Source: https://github.com/servo/rust-url/
  MIT: licenses/idna-1.1.0/LICENSE-MIT (crate license file)
idna_adapter 1.2.2
  License applied: MIT
  Authors: The rust-url developers
  Source: https://github.com/hsivonen/idna_adapter
  MIT: licenses/idna_adapter-1.2.2/LICENSE-MIT (crate license file)
image 0.25.10
  License applied: MIT
  Authors: The image-rs Developers
  Source: https://github.com/image-rs/image
  MIT: licenses/image-0.25.10/LICENSE-MIT (crate license file)
image-webp 0.2.4
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/image-rs/image-webp
  MIT: licenses/image-webp-0.2.4/LICENSE-MIT (crate license file)
indexmap 2.14.2
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/indexmap-rs/indexmap
  MIT: licenses/indexmap-2.14.2/LICENSE-MIT (crate license file)
itoa 1.0.18
  License applied: MIT
  Authors: David Tolnay <dtolnay@gmail.com>
  Source: https://github.com/dtolnay/itoa
  MIT: licenses/itoa-1.0.18/LICENSE-MIT (crate license file)
js-sys 0.3.106
  License applied: MIT
  Authors: The wasm-bindgen Developers
  Source: https://github.com/wasm-bindgen/wasm-bindgen/tree/master/crates/js-sys
  MIT: licenses/js-sys-0.3.106/LICENSE-MIT (crate license file)
keyboard-types 0.8.3
  License applied: MIT
  Authors: Pyfisch <pyfisch@posteo.org>
  Source: https://github.com/rust-windowing/keyboard-types
  MIT: licenses/keyboard-types-0.8.3/LICENSE-MIT (crate license file)
libm 0.2.16
  License applied: MIT
  Authors: Alex Crichton <alex@alexcrichton.com>; Amanieu d'Antras <amanieu@gmail.com>; Jorge Aparicio <japaricious@gmail.com>; Trevor Gross <tg@trevorgross.com>
  Source: https://github.com/rust-lang/compiler-builtins
  MIT: licenses/libm-0.2.16/LICENSE.txt (crate license file)
litemap 0.8.3
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/litemap-0.8.3/LICENSE (crate license file)
log 0.4.34
  License applied: MIT
  Authors: The Rust Project Developers
  Source: https://github.com/rust-lang/log
  MIT: licenses/log-0.4.34/LICENSE-MIT (crate license file)
memchr 2.8.3
  License applied: MIT
  Authors: Andrew Gallant <jamslam@gmail.com>; bluss
  Source: https://github.com/BurntSushi/memchr
  MIT: licenses/memchr-2.8.3/LICENSE-MIT (crate license file)
miniz_oxide 0.8.9
  License applied: MIT
  Authors: Frommi <daniil.liferenko@gmail.com>; oyvindln <oyvindln@users.noreply.github.com>; Rich Geldreich richgel99@gmail.com
  Source: https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide
  MIT: licenses/miniz_oxide-0.8.9/LICENSE-MIT.md (crate license file)
miniz_oxide 0.9.1
  License applied: MIT
  Authors: Frommi <daniil.liferenko@gmail.com>; oyvindln <oyvindln@users.noreply.github.com>; Rich Geldreich richgel99@gmail.com
  Source: https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide
  MIT: licenses/miniz_oxide-0.9.1/LICENSE-MIT.md (crate license file)
mint 0.5.9
  License applied: MIT
  Authors: Benjamin Saunders <ben.e.saunders@gmail.com>; Dzmitry Malyshau <kvarkus@gmail.com>; Evgenii P. <eupn@protonmail.com>; George Burton <burtonageo@gmail.com>; Ilya Bogdanov <fumlead@gmail.com>; Osspial <osspial@gmail.com>; Pâris DOUADY <paris.douady@hotmail.fr>; Rémi Lauzier <remilauzier@protonmail.com>
  Source: https://github.com/kvark/mint
  MIT: licenses/mint-0.5.9/LICENSE (crate license file)
moxcms 0.8.1
  License applied: BSD-3-Clause
  Authors: Radzivon Bartoshyk
  Source: https://github.com/awxkee/moxcms.git
  BSD-3-Clause: licenses/moxcms-0.8.1/LICENSE.md (crate license file)
naga 29.0.0
  License applied: MIT
  Authors: gfx-rs developers
  Source: https://github.com/gfx-rs/wgpu
  MIT: licenses/naga-29.0.0/LICENSE.MIT (crate license file)
naga-types 29.0.0
  License applied: MIT
  Authors: gfx-rs developers
  Source: https://github.com/gfx-rs/wgpu
  MIT: licenses/naga-types-29.0.0/LICENSE.MIT (crate license file)
num-traits 0.2.19
  License applied: MIT
  Authors: The Rust Project Developers
  Source: https://github.com/rust-num/num-traits
  MIT: licenses/num-traits-0.2.19/LICENSE-MIT (crate license file)
once_cell 1.21.4
  License applied: MIT
  Authors: Aleksey Kladov <aleksey.kladov@gmail.com>
  Source: https://github.com/matklad/once_cell
  MIT: licenses/once_cell-1.21.4/LICENSE-MIT (crate license file)
percent-encoding 2.3.2
  License applied: MIT
  Authors: The rust-url developers
  Source: https://github.com/servo/rust-url/
  MIT: licenses/percent-encoding-2.3.2/LICENSE-MIT (crate license file)
pin-project 1.1.13
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/taiki-e/pin-project
  MIT: licenses/pin-project-1.1.13/LICENSE-MIT (crate license file)
pin-project-lite 0.2.17
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/taiki-e/pin-project-lite
  MIT: licenses/pin-project-lite-0.2.17/LICENSE-MIT (crate license file)
png 0.18.1
  License applied: MIT
  Authors: The image-rs Developers
  Source: https://github.com/image-rs/image-png
  MIT: licenses/png-0.18.1/LICENSE-MIT (crate license file)
potential_utf 0.1.6
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/potential_utf-0.1.6/LICENSE (crate license file)
pxfm 0.1.30
  License applied: BSD-3-Clause
  Authors: Radzivon Bartoshyk
  Source: https://github.com/awxkee/pxfm
  BSD-3-Clause: licenses/pxfm-0.1.30/LICENSE.md (crate license file)
quick-error 2.0.1
  License applied: MIT
  Authors: Paul Colomiets <paul@colomiets.name>; Colin Kiegel <kiegel@gmx.de>
  Source: http://github.com/tailhook/quick-error
  MIT: licenses/quick-error-2.0.1/LICENSE-MIT (crate license file)
rand_core 0.6.4
  License applied: MIT
  Authors: The Rand Project Developers; The Rust Project Developers
  Source: https://github.com/rust-random/rand
  MIT: licenses/rand_core-0.6.4/LICENSE-MIT (crate license file)
raw-window-handle 0.6.2
  License applied: MIT
  Authors: Osspial <osspial@gmail.com>
  Source: https://github.com/rust-windowing/raw-window-handle
  MIT: licenses/raw-window-handle-0.6.2/LICENSE-MIT.md (crate license file)
rustc-hash 1.1.0
  License applied: MIT
  Authors: The Rust Project Developers
  Source: https://github.com/rust-lang-nursery/rustc-hash
  MIT: licenses/rustc-hash-1.1.0/LICENSE-MIT (crate license file)
serde 1.0.229
  License applied: MIT
  Authors: Erick Tryzelaar <erick.tryzelaar@gmail.com>; David Tolnay <dtolnay@gmail.com>
  Source: https://github.com/serde-rs/serde
  MIT: licenses/serde-1.0.229/LICENSE-MIT (crate license file)
serde_core 1.0.229
  License applied: MIT
  Authors: Erick Tryzelaar <erick.tryzelaar@gmail.com>; David Tolnay <dtolnay@gmail.com>
  Source: https://github.com/serde-rs/serde
  MIT: licenses/serde_core-1.0.229/LICENSE-MIT (crate license file)
serde_json 1.0.151
  License applied: MIT
  Authors: Erick Tryzelaar <erick.tryzelaar@gmail.com>; David Tolnay <dtolnay@gmail.com>
  Source: https://github.com/serde-rs/json
  MIT: licenses/serde_json-1.0.151/LICENSE-MIT (crate license file)
simd-adler32 0.3.10
  License applied: MIT
  Authors: Marvin Countryman <me@maar.vin>
  Source: https://github.com/mcountryman/simd-adler32
  MIT: licenses/simd-adler32-0.3.10/LICENSE.md (crate license file)
slab 0.4.12
  License applied: MIT
  Authors: Carl Lerche <me@carllerche.com>
  Source: https://github.com/tokio-rs/slab
  MIT: licenses/slab-0.4.12/LICENSE (crate license file)
slotmap 1.1.1
  License applied: Zlib
  Authors: Orson Peters <orsonpeters@gmail.com>
  Source: https://github.com/orlp/slotmap
  Zlib: licenses/slotmap-1.1.1/LICENSE (crate license file)
smallvec 1.16.2
  License applied: MIT
  Authors: The Servo Project Developers
  Source: https://github.com/servo/rust-smallvec
  MIT: licenses/smallvec-1.16.2/LICENSE-MIT (crate license file)
smol_str 0.3.6
  License applied: MIT
  Authors: Aleksey Kladov <aleksey.kladov@gmail.com>; Lukas Wirth <lukastw97@gmail.com>
  Source: https://github.com/rust-lang/rust-analyzer/tree/master/lib/smol_str
  MIT: licenses/smol_str-0.3.6/LICENSE-MIT (crate license file)
spirv 0.4.0+sdk-1.4.341.0
  License applied: Apache-2.0
  Authors: Lei Zhang <antiagainst@gmail.com>
  Source: https://github.com/gfx-rs/rspirv
  Apache-2.0: licenses/spirv-0.4.0+sdk-1.4.341.0/LICENSE-Apache-2.0.txt (standard SPDX text; crate archive has no license file)
stable_deref_trait 1.2.1
  License applied: MIT
  Authors: Robert Grosse <n210241048576@gmail.com>
  Source: https://github.com/storyyeller/stable_deref_trait
  MIT: licenses/stable_deref_trait-1.2.1/LICENSE-MIT (crate license file)
termcolor 1.4.1
  License applied: MIT
  Authors: Andrew Gallant <jamslam@gmail.com>
  Source: https://github.com/BurntSushi/termcolor
  MIT: licenses/termcolor-1.4.1/LICENSE-MIT (crate license file)
thiserror 2.0.21
  License applied: MIT
  Authors: David Tolnay <dtolnay@gmail.com>
  Source: https://github.com/dtolnay/thiserror
  MIT: licenses/thiserror-2.0.21/LICENSE-MIT (crate license file)
tinystr 0.8.4
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/tinystr-0.8.4/LICENSE (crate license file)
tracing 0.1.44
  License applied: MIT
  Authors: Eliza Weisman <eliza@buoyant.io>; Tokio Contributors <team@tokio.rs>
  Source: https://github.com/tokio-rs/tracing
  MIT: licenses/tracing-0.1.44/LICENSE (crate license file)
tracing-core 0.1.36
  License applied: MIT
  Authors: Tokio Contributors <team@tokio.rs>
  Source: https://github.com/tokio-rs/tracing
  MIT: licenses/tracing-core-0.1.36/LICENSE (crate license file)
unicode-ident 1.0.26
  License applied: MIT AND Unicode-3.0
  Authors: David Tolnay <dtolnay@gmail.com>
  Source: https://github.com/dtolnay/unicode-ident
  MIT: licenses/unicode-ident-1.0.26/LICENSE-MIT (crate license file)
  Unicode-3.0: licenses/unicode-ident-1.0.26/LICENSE-UNICODE (crate license file)
unicode-width 0.2.2
  License applied: MIT
  Authors: kwantam <kwantam@gmail.com>; Manish Goregaokar <manishsmail@gmail.com>
  Source: https://github.com/unicode-rs/unicode-width
  MIT: licenses/unicode-width-0.2.2/LICENSE-MIT (crate license file)
url 2.5.8
  License applied: MIT
  Authors: The rust-url developers
  Source: https://github.com/servo/rust-url
  MIT: licenses/url-2.5.8/LICENSE-MIT (crate license file)
utf8_iter 1.0.4
  License applied: MIT
  Authors: Henri Sivonen <hsivonen@hsivonen.fi>
  Source: https://github.com/hsivonen/utf8_iter
  MIT: licenses/utf8_iter-1.0.4/LICENSE-MIT (crate license file)
wasm-bindgen 0.2.129
  License applied: MIT
  Authors: The wasm-bindgen Developers
  Source: https://github.com/wasm-bindgen/wasm-bindgen
  MIT: licenses/wasm-bindgen-0.2.129/LICENSE-MIT (crate license file)
wasm-bindgen-futures 0.4.79
  License applied: MIT
  Authors: The wasm-bindgen Developers
  Source: https://github.com/wasm-bindgen/wasm-bindgen/tree/master/crates/futures
  MIT: licenses/wasm-bindgen-futures-0.4.79/LICENSE-MIT (crate license file)
wasm-bindgen-shared 0.2.129
  License applied: MIT
  Authors: The wasm-bindgen Developers
  Source: https://github.com/wasm-bindgen/wasm-bindgen/tree/master/crates/shared
  MIT: licenses/wasm-bindgen-shared-0.2.129/LICENSE-MIT (crate license file)
wasm-streams 0.4.2
  License applied: MIT
  Authors: Mattias Buelens <mattias@buelens.com>
  Source: https://github.com/MattiasBuelens/wasm-streams/
  MIT: licenses/wasm-streams-0.4.2/LICENSE-MIT (crate license file)
web-sys 0.3.106
  License applied: MIT
  Authors: The wasm-bindgen Developers
  Source: https://github.com/wasm-bindgen/wasm-bindgen/tree/master/crates/web-sys
  MIT: licenses/web-sys-0.3.106/LICENSE-MIT (crate license file)
web-time 1.1.0
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/daxpedda/web-time
  MIT: licenses/web-time-1.1.0/LICENSE-MIT (crate license file)
winit 0.31.0-beta.2
  License applied: Apache-2.0
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-windowing/winit
  Apache-2.0: licenses/winit-0.31.0-beta.2/LICENSE (crate license file)
winit-core 0.31.0-beta.2
  License applied: Apache-2.0
  Authors: The winit contributors; Kirill Chibisov <contact@kchibisov.com>
  Source: https://github.com/rust-windowing/winit
  Apache-2.0: licenses/winit-core-0.31.0-beta.2/LICENSE (crate license file)
winit-web 0.31.0-beta.2
  License applied: Apache-2.0
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/rust-windowing/winit
  Apache-2.0: licenses/winit-web-0.31.0-beta.2/LICENSE-Apache-2.0.txt (standard SPDX text; crate archive has no license file)
writeable 0.6.4
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/writeable-0.6.4/LICENSE (crate license file)
wyrand 0.2.1
  License applied: MIT
  Authors: Gonçalo Rica Pais da Silva <bluefinger@gmail.com>
  Source: https://github.com/Bluefinger/wyrand-rs
  MIT: licenses/wyrand-0.2.1/LICENSE-MIT (crate license file)
yoke 0.8.3
  License applied: Unicode-3.0
  Authors: Manish Goregaokar <manishsmail@gmail.com>
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/yoke-0.8.3/LICENSE (crate license file)
zerocopy 0.8.59
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/google/zerocopy
  MIT: licenses/zerocopy-0.8.59/LICENSE-MIT (crate license file)
zerofrom 0.1.8
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/zerofrom-0.1.8/LICENSE (crate license file)
zerotrie 0.2.5
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/zerotrie-0.2.5/LICENSE (crate license file)
zerovec 0.11.8
  License applied: Unicode-3.0
  Authors: The ICU4X Project Developers
  Source: https://github.com/unicode-org/icu4x
  Unicode-3.0: licenses/zerovec-0.11.8/LICENSE (crate license file)
zlib-rs 0.6.8
  License applied: Zlib
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/trifectatechfoundation/zlib-rs
  Zlib: licenses/zlib-rs-0.6.8/LICENSE (crate license file)
zmij 1.0.23
  License applied: MIT
  Authors: David Tolnay <dtolnay@gmail.com>
  Source: https://github.com/dtolnay/zmij
  MIT: licenses/zmij-1.0.23/LICENSE-MIT (crate license file)
zune-core 0.5.3
  License applied: MIT
  Authors: (not listed in Cargo metadata)
  Source: https://github.com/etemesi254/zune-image
  MIT: licenses/zune-core-0.5.3/LICENSE-MIT (crate license file)
zune-jpeg 0.5.15
  License applied: MIT
  Authors: caleb <etemesicaleb@gmail.com>
  Source: https://github.com/etemesi254/zune-image/tree/dev/crates/zune-jpeg
  MIT: licenses/zune-jpeg-0.5.15/LICENSE-MIT (crate license file)
